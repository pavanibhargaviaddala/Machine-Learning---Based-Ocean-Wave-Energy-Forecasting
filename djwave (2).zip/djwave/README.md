# 🌊 Wave Energy ML Forecasting System — Django

**Based on:** Machine Learning Applications in Wave Energy Forecasting (ICUE 2024, Pattaya)

---

## ⚡ Quick Start (3 commands)

```bash
# 1. Install
pip install -r requirements.txt

# 2. Setup DB + admin
python setup.py

# 3. Run
python manage.py runserver
```

Open: **http://127.0.0.1:8000**  
Login: `admin` / `admin123`

---

## ✨ Features

### User
- Register / Login (username OR email) / Logout
- Dashboard with project overview
- **ML Predictions** — 4 models auto-run, 8 comparison graphs, searchable table
- **Data Preprocessing** — 8-tile clickable grid: stats, correlation, distributions, time-series, feature engineering, scaling
- **Report** — view + download PDF
- **Profile Edit** — name, phone, bio, change password

### Admin
- Everything users see
- **Admin Dashboard** — stats + quick action tiles
- **User Management** — Add, Edit (role User↔Admin), Delete
- **Login Activity** — full log with search

---

## 🤖 Models (4 total)

| Category | Models | Description |
|----------|--------|-------------|
| **Ensemble** | **XGBoost** | **Primary model — 98.0% Accuracy (R²=0.98)**. Highly optimized gradient boosting. |
| **Ensemble** | **Random Forest** | Secondary ensemble model — **96.0% Accuracy**. Uses 300 decision trees. |
| **K-Nearest Neighbors** | **KNN** | **94.0% Accuracy**. Distance-based local regression (k=3). |
| **Regression** | **SVR** | Support Vector Regression with RBF kernel — **87.11% Accuracy**. |

---

## 📊 8 Comparison Graphs

1. Accuracy Bar Chart (horizontal, all models)
2. R² Score Bar Chart
3. RMSE Bar Chart
4. MAPE Bar Chart (sorted)
5. Radar Chart — Top 6 models
6. Actual vs Predicted Scatter — Top 3 models
7. Category Distribution Pie Chart
8. Feature Importance (Random Forest)

---

## 📁 Project Structure

```
wave_energy_django/
├── manage.py
├── setup.py           ← run once
├── requirements.txt
├── data/
│   └── wave_energy_forecasting_dataset.csv
├── waveproject/       ← Django project settings
│   ├── settings.py
│   └── urls.py
└── waveml/            ← main app
    ├── ml_engine.py   ← all 4 ML models + graphs
    ├── views.py
    ├── urls.py
    ├── models.py
    └── templates/
```
