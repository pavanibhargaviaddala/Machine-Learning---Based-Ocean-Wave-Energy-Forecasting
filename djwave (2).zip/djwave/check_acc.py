import os
import sys
import pandas as pd
import numpy as np

# Add project root to path
sys.path.append(os.getcwd())

from waveml.ml_engine import run_models

print("Checking current accuracies...")
results, graphs = run_models()

for r in results:
    print(f"{r['name']}: {r['acc']}% (R2: {r['r2']})")
