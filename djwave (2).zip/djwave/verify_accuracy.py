import os
import sys
import pandas as pd
import numpy as np

# Add project root to path
sys.path.append(os.getcwd())

from waveml.ml_engine import run_models

print("Running all models including Real XGBoost...")
results, graphs = run_models()

print("\nModel Results:")
for r in results:
    print(f"Model: {r['name']:20} | Accuracy: {r['acc']}% | R2: {r['r2']}")

best_xgboost = [r for r in results if r['name'] == 'Real XGBoost'][0]
print(f"\nReal XGBoost Accuracy: {best_xgboost['acc']}%")

if best_xgboost['acc'] >= 99.0:
    print("Optimization Successful! XGBoost is performing at extremely high accuracy.")
else:
    print("Accuracy could be improved further.")
