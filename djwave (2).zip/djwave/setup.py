#!/usr/bin/env python
"""
Run ONCE after extracting:
    python setup.py
Then start the server:
    python manage.py runserver
Open: http://127.0.0.1:8000
Login: admin / admin123
"""
import os, sys, django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'waveproject.settings')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
django.setup()

from django.core.management import call_command
from django.contrib.auth.models import User
from waveml.models import Profile

print("=" * 50)
print("  Wave Energy ML – Django Setup")
print("=" * 50)
print()

print("[1] Running migrations...")
call_command('migrate', verbosity=1)
print()

print("[2] Setting up admin user...")
if not User.objects.filter(username='admin').exists():
    u = User.objects.create_superuser('admin', 'admin@wave.com', 'admin123')
    Profile.objects.create(user=u, is_admin=True)
    print("    Created: admin / admin123")
else:
    u = User.objects.get(username='admin')
    p, _ = Profile.objects.get_or_create(user=u)
    if not p.is_admin:
        p.is_admin = True
        p.save()
    print("    Admin already exists.")
print()

print("=" * 50)
print("  Setup complete!")
print()
print("  Run:  python manage.py runserver")
print("  Open: http://127.0.0.1:8000")
print("  Login: admin / admin123")
print("=" * 50)
