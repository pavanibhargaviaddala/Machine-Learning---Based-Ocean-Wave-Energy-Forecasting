from django.db import models
from django.contrib.auth.models import User


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    is_admin = models.BooleanField(default=False)
    phone = models.CharField(max_length=30, blank=True)
    bio = models.TextField(blank=True)

    def __str__(self):
        return f'{self.user.username} - {"admin" if self.is_admin else "user"}'


class Activity(models.Model):
    username = models.CharField(max_length=150)
    action = models.CharField(max_length=20)   # LOGIN / LOGOUT
    ip = models.CharField(max_length=50, blank=True)
    ts = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-ts']
