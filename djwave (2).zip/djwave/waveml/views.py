import io
from functools import wraps

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import HttpResponse

from .models import Profile, Activity
from .ml_engine import run_models, preproc_info, predict_single


# ─── HELPERS ─────────────────────────────
def ensure_profile(user):
    Profile.objects.get_or_create(user=user)


def is_admin(user):
    if user.is_superuser:
        return True
    try:
        return user.profile.is_admin
    except:
        return False


def login_required(fn):
    @wraps(fn)
    def wrapped(req, *args, **kwargs):
        if not req.user.is_authenticated:
            return redirect('login')
        ensure_profile(req.user)
        return fn(req, *args, **kwargs)
    return wrapped


def admin_required(fn):
    @wraps(fn)
    def wrapped(req, *args, **kwargs):
        if not req.user.is_authenticated:
            return redirect('login')
        if not is_admin(req.user):
            return redirect('dashboard')
        return fn(req, *args, **kwargs)
    return wrapped


# ─── AUTH ─────────────────────────────
def root(req):
    if req.user.is_authenticated:
        return redirect('dashboard')
    return redirect('login')


def login_view(req):
    if req.method == 'POST':
        u = req.POST.get('identifier')
        p = req.POST.get('password')

        user = authenticate(req, username=u, password=p)
        if user:
            login(req, user)
            return redirect('dashboard')

        messages.error(req, 'Invalid login')

    return render(req, 'waveml/login.html')


def register_view(req):
    if req.method == 'POST':
        u = req.POST.get('username')
        e = req.POST.get('email')
        p1 = req.POST.get('password1')
        p2 = req.POST.get('password2')

        # password validation
        if p1 != p2:
            messages.error(req, 'Passwords do not match')
            return redirect('register')

        # username exists check
        if User.objects.filter(username=u).exists():
            messages.error(req, 'Username already exists')
            return redirect('register')

        # create user
        user = User.objects.create_user(
            username=u,
            email=e,
            password=p1
        )

        Profile.objects.create(user=user)

        messages.success(req, 'Registration successful. Please login.')
        return redirect('login')

    return render(req, 'waveml/register.html')


def logout_view(req):
    logout(req)
    return redirect('login')


# ─── DASHBOARD ─────────────────────────────
@login_required
def dashboard(req):
    results, _ = run_models()
    oxgb = next((r for r in results if r['name'] == 'XGBoost'), None)


    return render(req, 'waveml/dashboard.html', {
        'model_name': 'XGBoost',
        'accuracy': round(oxgb['acc'], 2) if oxgb else 0,
        'model_count': len(results)
    })



# ─── USER PAGES ─────────────────────────────
@login_required
def predictions(req):
    results, graphs = run_models()
    return render(req, 'waveml/predictions.html', {'results': results, 'graphs': graphs})


@login_required
def preprocessing(req):
    return render(req, 'waveml/preprocessing.html', {'info': preproc_info()})


@login_required
def report(req):
    results, _ = run_models()
    return render(req, 'waveml/report.html', {'results': results})


@login_required
def profile(req):
    return render(req, 'waveml/profile.html')


# ─── DOWNLOAD REPORT ─────────────────────────────
@login_required
def download_report(req):
    results, _ = run_models()

    from reportlab.platypus import SimpleDocTemplate, Table
    from reportlab.lib.pagesizes import A4

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)

    data = [['Model', 'Accuracy']]
    for r in results:
        data.append([r['name'], f"{r['acc']:.2f}"])

    doc.build([Table(data)])
    buffer.seek(0)
    return HttpResponse(buffer, content_type='application/pdf')


# ─── PREDICTION ─────────────────────────────
@login_required
def predict_view(req):
    result = None
    error = None

    if req.method == 'POST':
        try:
            inp = {
                'Significant_Wave_Height_m': float(req.POST.get('Significant_Wave_Height_m')),
                'Wave_Period_s': float(req.POST.get('Wave_Period_s')),
                'Wind_Speed_m_s': float(req.POST.get('Wind_Speed_m_s')),
                'Wind_Direction_deg': float(req.POST.get('Wind_Direction_deg')),
                'Atmospheric_Pressure_hPa': float(req.POST.get('Atmospheric_Pressure_hPa')),
                'Tidal_Height_m': float(req.POST.get('Tidal_Height_m')),
                'Hour': float(req.POST.get('Hour')),
                'Month': float(req.POST.get('Month')),
                'DayOfWeek': float(req.POST.get('DayOfWeek')),
            }

            result = predict_single(inp)

        except Exception as e:
            error = str(e)

    return render(req, 'waveml/predict.html', {
        'result': result,
        'error': error
    })


# ─── ADMIN FUNCTIONS ─────────────────────────────
@admin_required
def adm_dashboard(req):
    users = User.objects.all().order_by('-date_joined')
    total = users.count()
    admins = Profile.objects.filter(is_admin=True).count()
    acts = Activity.objects.all().order_by('-ts')

    return render(req, 'waveml/admin/dashboard.html', {
        'total': total,
        'admins': admins,
        'users': users,
        'acts': acts
    })


@admin_required
def adm_users(req):
    users = User.objects.all()
    return render(req, 'waveml/admin/users.html', {'users': users})


@admin_required
def adm_add_user(req):
    return render(req, 'waveml/admin/add_user.html')


@admin_required
def adm_edit_user(req, uid):
    user = get_object_or_404(User, pk=uid)
    return render(req, 'waveml/admin/edit_user.html', {'user': user})


@admin_required
def adm_del_user(req, uid):
    user = get_object_or_404(User, pk=uid)
    user.delete()
    return redirect('adm_users')


@admin_required
def adm_activity(req):
    acts = Activity.objects.all()
    return render(req, 'waveml/admin/activity.html', {'acts': acts})


@admin_required
def adm_predictions(req):
    results, graphs = run_models()
    return render(req, 'waveml/predictions.html', {'results': results, 'graphs': graphs})


@admin_required
def adm_preprocessing(req):
    return render(req, 'waveml/preprocessing.html', {'info': preproc_info()})


@admin_required
def adm_report(req):
    results, _ = run_models()
    return render(req, 'waveml/report.html', {'results': results})


@admin_required
def adm_predict(req):
    result = None
    error = None

    if req.method == 'POST':
        try:
            inp = {
                'Significant_Wave_Height_m': float(req.POST.get('Significant_Wave_Height_m')),
                'Wave_Period_s': float(req.POST.get('Wave_Period_s')),
                'Wind_Speed_m_s': float(req.POST.get('Wind_Speed_m_s')),
                'Wind_Direction_deg': float(req.POST.get('Wind_Direction_deg')),
                'Atmospheric_Pressure_hPa': float(req.POST.get('Atmospheric_Pressure_hPa')),
                'Tidal_Height_m': float(req.POST.get('Tidal_Height_m')),
                'Hour': float(req.POST.get('Hour')),
                'Month': float(req.POST.get('Month')),
                'DayOfWeek': float(req.POST.get('DayOfWeek')),
            }

            result = predict_single(inp)

        except Exception as e:
            error = str(e)

    return render(req, 'waveml/predict.html', {
        'result': result,
        'error': error
    })