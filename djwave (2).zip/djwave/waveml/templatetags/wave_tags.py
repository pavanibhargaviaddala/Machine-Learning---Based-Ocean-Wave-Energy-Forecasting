from django import template

register = template.Library()

@register.filter
def get_item(obj, key):
    """Get item from dict by key."""
    try:
        return obj[key]
    except (KeyError, TypeError, IndexError):
        return ''

@register.filter
def index(lst, i):
    """Get list item by index."""
    try:
        return lst[i]
    except (IndexError, TypeError):
        return ''

@register.filter
def multiply(value, arg):
    try:
        return float(value) * float(arg)
    except (ValueError, TypeError):
        return 0

@register.filter
def add_str(value, arg):
    return str(value) + str(arg)
