from django.urls import path
from . import views

urlpatterns = [
    path('',                         views.root,              name='root'),
    path('login/',                   views.login_view,        name='login'),
    path('register/',                views.register_view,     name='register'),
    path('logout/',                  views.logout_view,       name='logout'),

    # user
    path('dashboard/',               views.dashboard,         name='dashboard'),
    path('predictions/',             views.predictions,       name='predictions'),
    path('preprocessing/',           views.preprocessing,     name='preprocessing'),
    path('predict/',                 views.predict_view,      name='predict'),
    path('report/',                  views.report,            name='report'),
    path('report/download/',         views.download_report,   name='download_report'),
    path('profile/',                 views.profile,           name='profile'),

    # admin
    path('admin-panel/',             views.adm_dashboard,     name='adm_dashboard'),
    path('admin-panel/users/',       views.adm_users,         name='adm_users'),
    path('admin-panel/users/add/',   views.adm_add_user,      name='adm_add_user'),
    path('admin-panel/users/<int:uid>/edit/',   views.adm_edit_user,   name='adm_edit_user'),
    path('admin-panel/users/<int:uid>/delete/', views.adm_del_user,    name='adm_del_user'),
    path('admin-panel/activity/',    views.adm_activity,      name='adm_activity'),
    path('admin-panel/predictions/', views.adm_predictions,   name='adm_predictions'),
    path('admin-panel/preprocessing/', views.adm_preprocessing, name='adm_preprocessing'),
    path('admin-panel/report/',      views.adm_report,        name='adm_report'),
    path('admin-panel/predict/',     views.adm_predict,       name='adm_predict'),
]
