def global_ctx(request):
    is_adm = False
    if request.user.is_authenticated:
        if request.user.is_superuser:
            is_adm = True
        else:
            try:
                is_adm = request.user.profile.is_admin
            except Exception:
                pass
    return {'IS_ADMIN': is_adm}
