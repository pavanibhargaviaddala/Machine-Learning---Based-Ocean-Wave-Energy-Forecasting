from django.apps import AppConfig


class WavemlConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'waveml'
