from django.contrib import admin
from .models import Profile, Activity

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'is_admin', 'phone')
    list_filter = ('is_admin',)
    search_fields = ('user__username', 'phone')

@admin.register(Activity)
class ActivityAdmin(admin.ModelAdmin):
    list_display = ('username', 'action', 'ip', 'ts')
    list_filter = ('action',)
    search_fields = ('username', 'ip')
    readonly_fields = ('ts',)
