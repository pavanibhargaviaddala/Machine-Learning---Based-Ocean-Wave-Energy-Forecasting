import os
import sys
import pandas as pd
import numpy as np
from xgboost import XGBRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import r2_score

# Add the project directory to sys.path to import waveml
sys.path.append(os.getcwd())

# Mock load_data if it fails to import or use the one from ml_engine
try:
    from waveml.ml_engine import load_data
    Xtr, Xte, ytr, yte, features, df, sc = load_data()
except Exception as e:
    print(f"Error loading data: {e}")
    # Fallback to local data loading if necessary
    BASE_DIR = os.getcwd()
    DATA_CSV = os.path.join(BASE_DIR, 'data', 'wave_energy_forecasting_dataset.csv')
    df = pd.read_csv(DATA_CSV).dropna()
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    
    # Feature engineering as in ml_engine.py
    rho, g = 1025, 9.81
    df['Timestamp'] = pd.to_datetime(df['Timestamp'])
    df['Hour']      = df['Timestamp'].dt.hour
    df['Month']     = df['Timestamp'].dt.month
    df['DayOfWeek'] = df['Timestamp'].dt.dayofweek
    df['Wave_Energy_Flux']     = (1/16)*rho*g*(df['Significant_Wave_Height_m']**2)*df['Wave_Period_s']
    df['Wind_Wave_Interaction'] = df['Wind_Speed_m_s'] * df['Significant_Wave_Height_m']
    df['Wave_Steepness']        = df['Significant_Wave_Height_m'] / (df['Wave_Period_s']**2 + 1e-6)
    df['Pressure_Dev']          = df['Atmospheric_Pressure_hPa'] - df['Atmospheric_Pressure_hPa'].mean()
    df['Wave_Power_Approx']     = df['Significant_Wave_Height_m']**2 * df['Wave_Period_s']
    
    features = [
        'Significant_Wave_Height_m','Wave_Period_s','Wind_Speed_m_s',
        'Wind_Direction_deg','Atmospheric_Pressure_hPa','Tidal_Height_m',
        'Hour','Month','DayOfWeek',
        'Wave_Energy_Flux','Wind_Wave_Interaction',
        'Wave_Steepness','Pressure_Dev','Wave_Power_Approx',
    ]
    target = 'Wave_Power_Density_W_m2'
    X = df[features].values
    y = df[target].values
    sc = StandardScaler()
    Xs = sc.fit_transform(X)
    Xtr, Xte, ytr, yte = train_test_split(Xs, y, test_size=0.2, random_state=42)

print("Starting XGBoost Hyperparameter Tuning...")

param_grid = {
    'n_estimators': [500, 1000],
    'max_depth': [6, 8, 10],
    'learning_rate': [0.01, 0.05, 0.1],
    'subsample': [0.8, 1.0],
    'colsample_bytree': [0.8, 1.0],
}

xgb = XGBRegressor(random_state=42, n_jobs=-1)
grid_search = GridSearchCV(estimator=xgb, param_grid=param_grid, 
                           cv=3, scoring='r2', verbose=1)

grid_search.fit(Xtr, ytr)

print(f"Best parameters found: {grid_search.best_params_}")
print(f"Best R2 score: {grid_search.best_score_}")

# Evaluate on test set
best_model = grid_search.best_estimator_
y_pred = best_model.predict(Xte)
test_r2 = r2_score(yte, y_pred)
print(f"Test R2 score: {test_r2}")
print(f"Test Accuracy: {test_r2 * 100:.2f}%")
