import os
import sys
import pandas as pd
import numpy as np
from xgboost import XGBRegressor
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import r2_score

# Add the project directory to sys.path to import waveml
sys.path.append(os.getcwd())

try:
    from waveml.ml_engine import load_data
    Xtr, Xte, ytr, yte, features, df, sc = load_data()
except Exception as e:
    print(f"Error loading data: {e}")
    sys.exit(1)

print("Starting FAST XGBoost Hyperparameter Tuning...")

param_grid = {
    'n_estimators': [100, 500],
    'max_depth': [3, 6],
    'learning_rate': [0.05, 0.1],
}

xgb = XGBRegressor(random_state=42, n_jobs=-1)
grid_search = GridSearchCV(estimator=xgb, param_grid=param_grid, 
                           cv=3, scoring='r2', verbose=1)

grid_search.fit(Xtr, ytr)

print(f"Best parameters found: {grid_search.best_params_}")
print(f"Best R2 score: {grid_search.best_score_}")

# Evaluate on test set
best_model = grid_search.best_estimator_
y_pred = best_model.predict(Xte)
test_r2 = r2_score(yte, y_pred)
print(f"Test R2 score: {test_r2}")
print(f"Test Accuracy: {test_r2 * 100:.2f}%")
